# Aryan Acharya — Personal Portfolio

A responsive one-page portfolio built from the information in the supplied resume.

## Run locally
Open `index.html` in a browser.

## Publish
Upload the folder to any static hosting service (GitHub Pages, Vercel, Netlify, etc.).
Before publishing, replace the placeholder LinkedIn URL in `index.html` with your actual profile URL.

## Content note
No work experience, projects, links, metrics, or technologies were invented beyond the supplied resume.
